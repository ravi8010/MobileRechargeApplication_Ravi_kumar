package com.cq.mra.service;

import com.cq.mra.beans.Account;
import com.cq.mra.dao.AccountDao;
import com.cq.mra.dao.AccountDaoImpl;
import com.cq.mra.exception.MobileDoesNotExist;

public class AccountServiceImpl implements AccountService {
AccountDao accdao=new AccountDaoImpl(); //creation the object of dao class

	@Override
	public Account getAccountDetails(String mobileNo) throws MobileDoesNotExist {
		if(accdao.getAccountDetails(mobileNo)==null)
			throw new MobileDoesNotExist();
		return accdao.getAccountDetails(mobileNo); // it will call the getAccountDetails method through the object of account dao class
		
	}

	@Override
	public double rechargeAccount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		accdao.rechargeAccount(mobileNo, amount); //it will call the rechargeAmount() method through the object of account dao class
		return 1;
		
	}

}
