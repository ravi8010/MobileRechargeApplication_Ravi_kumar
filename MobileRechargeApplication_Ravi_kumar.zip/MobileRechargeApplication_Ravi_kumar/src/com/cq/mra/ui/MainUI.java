package com.cq.mra.ui;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.cq.mra.exception.MobileDoesNotExist;
import com.cq.mra.service.AccountService;
import com.cq.mra.service.AccountServiceImpl;

public class MainUI {
	static AccountService acs=new AccountServiceImpl(); //creation of object of service class 
	static Scanner sc=new Scanner(System.in);// creation of Scanner object
	
	public static void main(String[] args) throws MobileDoesNotExist  {
		
	       while(true)
	       {
	    	   System.out.println("--------Mobile Application-------"); 
	    	   System.out.println("1) Balance Enquiry\n2) Recharge Account\n3) Exit");//display the menu
	            System.out.println("Enter Your Choice:"); //user will ask for the choice
	            int ch=sc.nextInt();
	            sc.nextLine();
	            switch(ch) //switch case
	            {
	            case 1:balanceEnquirey(); //method which will call balanceEnquirey() method when use will press 1
	            break;
	            case 2:rechargeAccount(); //method which will call rechargeAccount() method when use will press 2
	            break;
	            case 3:System.exit(0);
	            break;
	            default:System.out.println("Wrong invalid");//if user enter wrong input
	            }
	      
	       }

	}

	private static void rechargeAccount()   {
		// TODO Auto-generated method stub
		System.out.print("Enter Mobile No:");
		String mobileNo=sc.nextLine();
		while(!(validateMobileNo(mobileNo)))  //if inner condtion false then it will return true and ask again for the valid mobile no
		{
			System.out.print("Enter valid Mobile No:");
			mobileNo=sc.nextLine();
		}
		try {
			if(acs.getAccountDetails(mobileNo)!=null) //if mobile no. will exist then go in otherwise print error message 
			{
				System.out.print("Enter amount: "); //ask for the amount to be recharge
				double amount=sc.nextDouble();
				while(!(validateAmount(amount))) // it will check the valid balance unit user enters valid amount
				{
					System.out.print("Enter valid amount: ");
					amount=sc.nextDouble();
				}
					sc.nextLine();
					acs.rechargeAccount(mobileNo, amount);
					System.out.println("Your Account Recharged Successfully");
					
					System.out.println("Hello, "+acs.getAccountDetails(mobileNo).getCustomerName()+" Available Balance is "+acs.getAccountDetails(mobileNo).getAccountBalance());;
				//Display the totatl balance 	
				
			}
			
			else
			{
				System.err.println("Can't Recharge Account as Given Mobile No. Does Not Exists");
			}
		} catch (MobileDoesNotExist e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	private static void balanceEnquirey()  {
		// TODO Auto-generated method stub
		System.out.print("Enter Mobile Number: ");
        String mobileNo=sc.nextLine();
        while(!(validateMobileNo(mobileNo))) //validate mobile number
		{
			System.out.print("Enter valid Mobile No: ");
			mobileNo=sc.nextLine();
		}
       
			try {
				if(acs.getAccountDetails(mobileNo)!=null)
				{
					System.out.println("your Account Balance is:"+acs.getAccountDetails(mobileNo).getAccountBalance());// display account balance after recharge
				}
				
				else
				{
					System.err.println("Given Account Id Does Not Exists");

				}
			} catch (MobileDoesNotExist e) {
			
				System.out.println(e.getMessage());
			}
		}
	public static boolean validateMobileNo(String mobileNo) //method for valid Mobile number 
	{
		if(Pattern.matches("((0/91)?[7-9][0-9]{9})",mobileNo)) // it will check the mobile no should be of numeric, 10 digit,starting with 7-9,
		{
			return true;
		}
		return false;
		
	}
	public static boolean validateAmount(double amount)
	{
		if(amount>0) //amount should be greater than 0
		{
			return true;
		}
		return false;
	}
	}


