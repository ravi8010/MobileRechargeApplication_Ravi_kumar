package com.cq.mra.exception;

public class MobileDoesNotExist extends Exception { //exception class for mobile does not exist
public String getMessage()
{
	return "Account Id Does not Exist"; //if mobile number does not exist then print the error message
			}
}
