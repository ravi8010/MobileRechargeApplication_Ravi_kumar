package com.cq.mra.junit;

import org.junit.Before;
import org.junit.Test;

import com.cq.mra.exception.MobileDoesNotExist;
import com.cq.mra.service.AccountService;
import com.cq.mra.service.AccountServiceImpl;

public class JunitTestCase {
AccountService accountService;
	@Before
	public void setUp() throws Exception {
		accountService=new AccountServiceImpl();
		
	}

	@Test(expected=com.cq.mra.exception.MobileDoesNotExist.class)
	public void test() throws MobileDoesNotExist {
		accountService.getAccountDetails("9010210134");
	}
	@Test
	public void rechargedSuccessfull()
	{
		accountService.rechargeAccount("9010210131", 2000);
	}
	

}
