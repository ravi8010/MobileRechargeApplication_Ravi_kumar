package com.cq.mra.dao;

import com.cq.mra.beans.Account;
import com.cq.mra.exception.MobileDoesNotExist;

public interface AccountDao {
Account getAccountDetails(String mobileNo);
double rechargeAccount(String mobileNo,double rechargeAmount);
}
