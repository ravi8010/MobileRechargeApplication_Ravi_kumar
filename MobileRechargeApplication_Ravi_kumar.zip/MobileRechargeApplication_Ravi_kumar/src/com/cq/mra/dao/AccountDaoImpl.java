package com.cq.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cq.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	
	
	Map<String,Account> accountEntry; //reference of Map 
	public AccountDaoImpl() 
	{
		accountEntry=new HashMap<>(); //object of HashMap which will store the data
		accountEntry.put("9010210131", new Account("Prepaid","Vaishali",200));
		accountEntry.put("9823920123", new Account("Prepaid","Megha",453));
		accountEntry.put("9932012345", new Account("Prepaid","Vikas",631));
		accountEntry.put("9010210133", new Account("Prepaid","Anju",521));//duplicate Mobile no so I have changed the Mobile
		accountEntry.put("9010210132", new Account("Prepaid","Tushar",632));//duplicate Mobile no so I have changed the Mobile
		

	}

	@Override
	public Account getAccountDetails(String mobileNo) {  //Method to get the recharge details using mobile number
		// TODO Auto-generated method stub
	 
		if(accountEntry.containsKey(mobileNo)) //find the accountEntry by mobile no if exist then return detail otherwise null
		{

			return accountEntry.get(mobileNo); //return account entry
		
		}
		
		return null;
		
	
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {//method to recharge Account
		// TODO Auto-generated method stub
		if(accountEntry.containsKey(mobileNo))        //find into Map by the mobile the mobile number
		{
			Account account=accountEntry.get(mobileNo); //store the details in Account
			account.setAccountBalance(account.getAccountBalance()+rechargeAmount); //it will set the add the amount that user will give in the previous one
			return 1;
		}
		return 0;
		
	}

}
